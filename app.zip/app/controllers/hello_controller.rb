class HelloController < ApplicationController
    
    
    def index

    end

    def privacy
    end
end
